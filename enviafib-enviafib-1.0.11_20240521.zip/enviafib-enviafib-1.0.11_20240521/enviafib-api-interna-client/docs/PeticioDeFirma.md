

# PeticioDeFirma

Elements retornats. Pot retornar un null o una llista buida si no hi ha elements.

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**nif** | **String** |  |  [optional] |
|**titol** | **String** |  |  [optional] |
|**creada** | **OffsetDateTime** |  |  [optional] |
|**finalitzada** | **OffsetDateTime** |  |  [optional] |
|**idiomaCode** | **String** |  |  [optional] |
|**idiomaDescription** | **String** |  |  [optional] |
|**tipusDocumentalCode** | **String** |  |  [optional] |
|**tipusDocumentalDescription** | **String** |  |  [optional] |
|**tipusPeticioCode** | **Integer** |  |  [optional] |
|**tipusPeticioDescription** | **String** |  |  [optional] |
|**dir3** | **String** |  |  [optional] |



