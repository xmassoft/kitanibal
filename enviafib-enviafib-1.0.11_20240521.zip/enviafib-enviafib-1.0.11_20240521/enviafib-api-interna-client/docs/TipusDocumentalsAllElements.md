

# TipusDocumentalsAllElements


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**name** | **String** | Nom descriptiu del que s&#39;està retornant |  |
|**totalCount** | **Integer** | Número total d&#39;elements |  |
|**dateDownload** | **String** | Data i hora en que s&#39;han retornat les dades. Format ISO-8601 |  |
|**data** | [**List&lt;TipusDocumental&gt;**](TipusDocumental.md) | Elements retornats. Pot retornar un null o una llista buida si no hi ha elements. |  [optional] |



