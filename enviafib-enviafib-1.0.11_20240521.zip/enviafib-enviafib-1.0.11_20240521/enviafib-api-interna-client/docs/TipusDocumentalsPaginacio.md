

# TipusDocumentalsPaginacio


## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**page** | **Integer** | Número pàgina. Comença per 1. |  |
|**pagesize** | **Integer** | Mida de pàgina |  |
|**totalpages** | **Integer** | Número total de pàgines |  |
|**totalcount** | **Integer** | Numero total d&#39;elements |  |
|**data** | **List&lt;String&gt;** | Elements retornats |  |



