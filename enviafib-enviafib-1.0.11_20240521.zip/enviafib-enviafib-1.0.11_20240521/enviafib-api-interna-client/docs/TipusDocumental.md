

# TipusDocumental

Informació bàsica d'un Tipus Documental

## Properties

| Name | Type | Description | Notes |
|------------ | ------------- | ------------- | -------------|
|**code** | **String** | Identificador intern de l&#39;objecte |  |
|**name** | **String** | Nom del Tipus Documental |  |



