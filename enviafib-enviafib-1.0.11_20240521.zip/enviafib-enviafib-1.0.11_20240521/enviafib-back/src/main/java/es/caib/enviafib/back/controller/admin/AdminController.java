package es.caib.enviafib.back.controller.admin;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * 
 * @author anadal
 *
 */
@Controller
@RequestMapping(value = "/admin")
public class AdminController {
    
    
}
