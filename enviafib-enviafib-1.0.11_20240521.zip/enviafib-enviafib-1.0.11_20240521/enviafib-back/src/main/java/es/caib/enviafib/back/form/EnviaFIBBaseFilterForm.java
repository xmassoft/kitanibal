package es.caib.enviafib.back.form;

import org.fundaciobit.genapp.common.web.form.BaseFilterForm;

/**
 * 
 * @author anadal
 *
 */
public abstract class EnviaFIBBaseFilterForm extends BaseFilterForm {
  
  
  
  public EnviaFIBBaseFilterForm() {
  }
  
  
  
  public EnviaFIBBaseFilterForm(EnviaFIBBaseFilterForm __toClone) {
    super(__toClone);
  }
  

}
