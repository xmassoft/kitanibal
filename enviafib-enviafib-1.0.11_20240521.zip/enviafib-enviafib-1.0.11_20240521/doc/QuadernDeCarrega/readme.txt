INSTRUCCIONS PER NOU QUADERN DE CÀRREGA D'ENVIAFIB

(1) Compilar projecte amb caib.bat
(2) Executar generafitxers.bat
(5) Crear un zip amb el directori fitxers
(4) Pujar el zip a BOX CAIB (https://intranet.caib.es/boxcaibfront/)

(5) Crear un TAG del projecte

(6) Crear carpeta enviafib_x.y.z_anymesdia (enviafib_1.0.6_20230215)
(7) Incloure fitxers.zip
(8) Incloure enviafib.ear
(9) Incloure el tag de github

(10) Crea carpeta enviafib_x.y.z (enviafib_1.0.6)
(11) Adaptar la plantilla de QuadernDeCarrega.odt
(12) Guardar nou quadern de càrrega amb el nom: INANYMESDIAENVIAFIBDEV.odt (IN230515ENVIAFIBDEV.odt)
