/*
 * JBossWS WS-Tools Generated Source
 *
 * Generation Date: Sun Feb 07 20:49:56 CET 2010
 *
 * This generated source code represents a derivative work of the input to
 * the generator that produced it. Consult the input for the copyright and
 * terms of use that apply to this source code.
 */

package org.jboss.test.ws.jaxrpc.samples.jsr109ejb;


public class  JaxRpcTestService_echoSimpleUserType_RequestStruct
{

protected java.lang.String string_1;

protected org.jboss.test.ws.jaxrpc.samples.jsr109ejb.SimpleUserType simpleUserType_2;
public JaxRpcTestService_echoSimpleUserType_RequestStruct(){}

public JaxRpcTestService_echoSimpleUserType_RequestStruct(java.lang.String string_1, org.jboss.test.ws.jaxrpc.samples.jsr109ejb.SimpleUserType simpleUserType_2){
this.string_1=string_1;
this.simpleUserType_2=simpleUserType_2;
}
public java.lang.String getString_1() { return string_1 ;}

public void setString_1(java.lang.String string_1){ this.string_1=string_1; }

public org.jboss.test.ws.jaxrpc.samples.jsr109ejb.SimpleUserType getSimpleUserType_2() { return simpleUserType_2 ;}

public void setSimpleUserType_2(org.jboss.test.ws.jaxrpc.samples.jsr109ejb.SimpleUserType simpleUserType_2){ this.simpleUserType_2=simpleUserType_2; }

}
